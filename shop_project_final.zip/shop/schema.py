import graphene
from graphene_django import DjangoObjectType
from .models import Shop

class ShopType(DjangoObjectType):
    class Meta:
        model=Shop

class Query(graphene.ObjectType):
    all_shops=graphene.List(ShopType)
    def resolve_all_shops(root,info):
        return Shop.objects.all()

class CreateShop(graphene.Mutation):
    class Arguments:
        name=graphene.String()
        email=graphene.List(graphene.String)
        phone=graphene.List(graphene.String)
        address=graphene.String()
    shop=graphene.Field(ShopType)
    def mutate(self,info,name,email,phone,address):
        shop=Shop(name=name,email=email,phone=phone,address=address)
        shop.save()
        return CreateShop(shop=shop)

class Mutation(graphene.ObjectType):
    create_shop=CreateShop.Field()

schema=graphene.Schema(query=Query,mutation=Mutation)
