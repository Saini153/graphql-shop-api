from django.db import models
class Shop(models.Model):
    name=models.CharField(max_length=100)
    email=models.JSONField()
    phone=models.JSONField()
    address=models.TextField()
