# 🛒 GraphQL Shop API

## 🚀 Overview
A GraphQL API built using Django & Graphene to perform CRUD operations on a Shop model.

---

## 📊 Project Flow Diagram
![Flow Diagram](diagram.png)

---

## ⚙️ Setup
```bash
pip install django graphene-django
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

Open: http://127.0.0.1:8000/graphql/

---

## 🧪 Example Query
```graphql
query {
  allShops {
    name
  }
}
```

---

## 👤 Author
Sumit  
📞 9817543285  
📧 sainisaini9817@gmail.com
